package com.Hospital.Management.System.Repositries;

import java.util.List;

import aj.org.objectweb.asm.commons.Remapper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Hospital.Management.System.Entity.Doctor;
@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long>{

    Remapper findByUserId(Long doctorId);

    @Query("SELECT d.id FROM Doctor d WHERE d.user.id = :userId")
    Long findDoctorIdByUserId(@Param("userId") Long userId);
}
