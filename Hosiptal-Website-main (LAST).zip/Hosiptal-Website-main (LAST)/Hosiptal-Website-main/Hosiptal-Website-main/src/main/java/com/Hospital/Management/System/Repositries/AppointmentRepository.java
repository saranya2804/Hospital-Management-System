package com.Hospital.Management.System.Repositries;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.Hospital.Management.System.Entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

import com.Hospital.Management.System.Entity.Appointment;
import com.Hospital.Management.System.Entity.Doctor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByDoctor_Id(Long doctorId); // Use 'doc // Use 'doctor_Id' instead of 'doctorId'

    List<Appointment> findByPatient_Id(Long patientId);

    List<Appointment> findByPatient(Patient patient);

    Optional<Appointment> findByDoctorAndAppointmentDateAndSlot(Doctor doctor, LocalDate appointmentDate, String slot);

    Long countByDoctorId(Long doctorId);

    List<Appointment> findByDoctorIdAndStatus(Long doctorId, String pending);

    Long countByDoctorIdAndStatus(Long doctorId, String pending);
    @Query("SELECT COUNT(DISTINCT a.patient.id) FROM Appointment a WHERE a.doctor.id = :doctorId")
    Long countDistinctPatientsByDoctorId(@Param("doctorId") Long doctorId);
}
