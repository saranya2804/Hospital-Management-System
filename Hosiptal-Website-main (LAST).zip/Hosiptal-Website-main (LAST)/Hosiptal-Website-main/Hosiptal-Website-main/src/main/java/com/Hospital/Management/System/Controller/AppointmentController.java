package com.Hospital.Management.System.Controller;
import com.Hospital.Management.System.Entity.Appointment;
import com.Hospital.Management.System.Entity.DoctorAvailability;
import com.Hospital.Management.System.Service.AppointmentService;
import com.Hospital.Management.System.Service.DoctorService;
import com.Hospital.Management.System.dto.AppointmentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;
    @Autowired
    private DoctorService doctorService;

    @PostMapping
    public ResponseEntity<AppointmentDTO> createAppointment(@RequestBody AppointmentDTO appointmentDTO) {
        try {
            // Call service method to handle the appointment creation and conversion to DTO
            AppointmentDTO createdAppointment = appointmentService.createAppointment(appointmentDTO);
            return ResponseEntity.ok(createdAppointment);  // Return the created appointment DTO
        } catch (RuntimeException e) {
            // Return an error message if slot is already booked
            return ResponseEntity.badRequest().body(new AppointmentDTO("Error: " + e.getMessage()));
        }
    }
    @PutMapping("/{appointmentId}/status")
    public ResponseEntity<AppointmentDTO> updateAppointmentStatus(@PathVariable Long appointmentId, @RequestBody String status) {
        AppointmentDTO updatedAppointment = appointmentService.updateAppointmentStatus(appointmentId, status);
        return ResponseEntity.ok(updatedAppointment);
    }
    @GetMapping("/byPatientId/{PatientId}")
    public ResponseEntity<List<AppointmentDTO>> getAppointmentByPatientId(@PathVariable Long PatientId) {
        List<AppointmentDTO> appointments = appointmentService.getAllAppointmentByPatientId(PatientId);
        return ResponseEntity.ok(appointments);
    }
    @GetMapping("/appointmentcount/{doctorId}")
    public ResponseEntity<Long> getAppointmentCountByDoctorId(@PathVariable Long doctorId) {
        Long count = appointmentService.getAppointmentCountByDoctorId(doctorId);
        return ResponseEntity.ok(count);
    }
    @GetMapping("/appointmentcount")
    public ResponseEntity<Long> getTotalAppointmentCount() {
        Long count = appointmentService.getTotalAppointmentCount();
        return ResponseEntity.ok(count);
    }
    @GetMapping("/all")
    public ResponseEntity<List<Appointment>> getAllAppointments() {
        List<Appointment> appointments = (List<Appointment>) appointmentService.getAllAppointments(); // Make sure this service method exists
        return ResponseEntity.ok(appointments);
    }
    @PutMapping("/{appointmentId}/prescription")
    public ResponseEntity<?> updatePrescription(@PathVariable Long appointmentId, @RequestBody String prescriptionText) {
        if (appointmentId == null) {
            return ResponseEntity.badRequest().body("Appointment ID is required");
        }
        Optional<Appointment> appointmentOpt = appointmentService.findById(appointmentId);
        if (!appointmentOpt.isPresent()) {
            return ResponseEntity.notFound().build();
        }

        Appointment appointment = appointmentOpt.get();
        appointment.setPrescription(prescriptionText);
        appointmentService.save(appointment);

        return ResponseEntity.ok("Prescription updated successfully");
    }

    @PutMapping("/{appointmentId}/status/accept")
    public ResponseEntity<Appointment> acceptAppointment(@PathVariable Long appointmentId) {
        Appointment appointment = doctorService.acceptAppointment(appointmentId);
        return ResponseEntity.ok(appointment);
    }

    @PutMapping("/{appointmentId}/status/decline")
    public ResponseEntity<Appointment> declineAppointment(@PathVariable Long appointmentId) {
        Appointment appointment = doctorService.declineAppointment(appointmentId);
        return ResponseEntity.ok(appointment);
    }

    @GetMapping("getPendingAppointmentsCount/{doctorId}")
    public ResponseEntity<Long> getPendingAppointmentsCount(@PathVariable Long doctorId) {
        Long count = appointmentService.getPendingAppointmentsCount(doctorId);
        return ResponseEntity.ok(count);
    }
    @GetMapping("/getPatientCount/{doctorId}")
    public ResponseEntity<Long> getPatientCount(@PathVariable Long doctorId) {
        Long count = appointmentService.getPatientDistinctCount(doctorId);
        return ResponseEntity.ok(count);
    }
    @GetMapping("/getAcceptedAppointmentsCount/{doctorId}")
    public ResponseEntity<Long> getAcceptedAppointmentsCount(@PathVariable Long doctorId) {
        Long count = appointmentService.getAcceptedAppointmentsCount(doctorId);
        return ResponseEntity.ok(count);
    }
    @GetMapping("/getAvailableSlotsAndDate/{doctorId}")
    public ResponseEntity<List<DoctorAvailability>> getAvailableSlotsAndDate(@PathVariable Long doctorId) {
        List<DoctorAvailability> availableSlots = appointmentService.getAvailableSlotsAndDate(doctorId);
        return ResponseEntity.ok(availableSlots);
    }

}
