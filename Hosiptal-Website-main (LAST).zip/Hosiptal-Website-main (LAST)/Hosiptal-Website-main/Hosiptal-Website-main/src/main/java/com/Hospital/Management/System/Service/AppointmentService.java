package com.Hospital.Management.System.Service;

import com.Hospital.Management.System.Entity.Appointment;
import com.Hospital.Management.System.Entity.Doctor;
import com.Hospital.Management.System.Entity.DoctorAvailability;
import com.Hospital.Management.System.Entity.Patient;
import com.Hospital.Management.System.Repositries.AppointmentRepository;
import com.Hospital.Management.System.Repositries.DoctorAvailabilityRepository;
import com.Hospital.Management.System.Repositries.DoctorRepository;
import com.Hospital.Management.System.Repositries.PatientRepository;
import com.Hospital.Management.System.dto.AppointmentDTO;
import com.Hospital.Management.System.exceptions.ResourceNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;
    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private DoctorAvailabilityRepository doctoravalabilityrepo;

    public AppointmentDTO createAppointment(AppointmentDTO appointmentDTO) {
        // Fetch the Patient and Doctor by their IDs
        Patient patient = patientRepository.findById(appointmentDTO.getPatientId())
                .orElseThrow(() -> new RuntimeException("Patient not found"));

        Doctor doctor = doctorRepository.findById(appointmentDTO.getDoctorId())
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        // Check if the slot is already booked for the given date
        Optional<Appointment> existingAppointment = appointmentRepository.findByDoctorAndAppointmentDateAndSlot(doctor, appointmentDTO.getAppointmentDate(), appointmentDTO.getSlot());
        if (existingAppointment.isPresent()) {
            throw new RuntimeException("The slot is already booked for this doctor on the given date");
        }

        // Create a new Appointment
        Appointment appointment = new Appointment();
        appointment.setAppointmentDate(appointmentDTO.getAppointmentDate());
        appointment.setFee(appointmentDTO.getFee());
        appointment.setStatus(appointmentDTO.getStatus());
        appointment.setSlot(appointmentDTO.getSlot());
        appointment.setHealthIssue(appointmentDTO.getHealthIssue());
        appointment.setPrescription(appointmentDTO.getPrescription());

        // Set the Doctor and Patient objects
        appointment.setPatient(patient);
        appointment.setDoctor(doctor);

        // Set doctor and patient names (optional)
        appointment.setPatientname(patient.getName());
        appointment.setDoctorname(doctor.getName());

        // Save the appointment
        Appointment savedAppointment = appointmentRepository.save(appointment);

        // Return the saved appointment as a DTO
        return convertToDto(savedAppointment);
    }


    private AppointmentDTO convertToDto(Appointment appointment) {
        return new AppointmentDTO(
                appointment.getId(),
                appointment.getAppointmentDate(),
                appointment.getPatient().getId(),
                appointment.getDoctor().getId(),
                appointment.getPatientname(),
                appointment.getDoctorname(),
                appointment.getFee(),
                appointment.getStatus(),
                appointment.getSlot(),
                appointment.getHealthIssue(),
                appointment.getPrescription()
        );
    }

    public AppointmentDTO updateAppointmentStatus(Long appointmentId, String status) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        appointment.setStatus(status);
        appointmentRepository.save(appointment);
        return convertToDto(appointment);
    }

    public AppointmentDTO getAppointmentById(Long id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        return convertToDto(appointment);
    }

    public Object getAllAppointments() {
        List<Appointment> appointments = appointmentRepository.findAll();
        return appointments.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    public void deleteAppointment(Long id) {
        if (!appointmentRepository.existsById(id)) {
            throw new ResourceNotFoundException("Appointment not found");
        }
        appointmentRepository.deleteById(id);
    }

    public List<AppointmentDTO> getAllAppointmentByPatientId(Long patientId) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        List<Appointment> appointments = appointmentRepository.findByPatient(patient);
        return appointments.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    public int getAppointmentCount() {
        return (int) appointmentRepository.count();
    }

    public Optional<Appointment> findById(Long appointmentId) {
        return appointmentRepository.findById(appointmentId);
    }

    public void save(Appointment appointment) {
        appointmentRepository.save(appointment);
    }

    public Long getAppointmentCountByDoctorId(Long doctorId) {
        return appointmentRepository.countByDoctorId(doctorId);
    }

    public Long getTotalAppointmentCount() {
        return appointmentRepository.count();
    }

    public Long getPendingAppointmentsCount(Long doctorId) {
        return appointmentRepository.countByDoctorIdAndStatus(doctorId, "Pending");
    }


    public Long getPatientDistinctCount(Long doctorId) {
        return appointmentRepository.countDistinctPatientsByDoctorId(doctorId);
    }

    public Long getAcceptedAppointmentsCount(Long doctorId) {
        return appointmentRepository.countByDoctorIdAndStatus(doctorId, "Accepted");
    }

    public List<DoctorAvailability> getAvailableSlotsAndDate(Long doctorId) {
        return doctoravalabilityrepo.findAvailableSlotsAndDateByDoctorId(doctorId);
    }
}
