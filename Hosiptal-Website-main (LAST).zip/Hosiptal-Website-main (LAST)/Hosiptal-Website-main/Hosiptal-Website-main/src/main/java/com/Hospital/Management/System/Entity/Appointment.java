package com.Hospital.Management.System.Entity;

import java.time.LocalDate;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "appointments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDate appointmentDate;

    @Column(nullable = false)
    private Double fee;

    @Column(nullable = false)
    private String status = "Pending"; // Default value for status

    @ManyToOne
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @ManyToOne
    @JoinColumn(name = "doctor_id", nullable = false)
    private Doctor doctor; // This should correctly map the doctor entity

    @Column(nullable = false)
    private String slot;

    @Column(nullable = false)
    private String healthIssue;

    private String prescription; // Optional, no null constraints required

    private String doctorname;
    private String patientname;

}
