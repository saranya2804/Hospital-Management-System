package com.Hospital.Management.System.Entity;

import jakarta.persistence.Entity;

public enum Role {
	    ADMIN,
	    DOCTOR,
	    PATIENT;

	public String toUpperCase() {
		return this.name().toUpperCase();
	}
}

