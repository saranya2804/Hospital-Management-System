package com.Hospital.Management.System.dto;

import com.Hospital.Management.System.Entity.Role;
import com.Hospital.Management.System.Entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserDTO {

    private Long id;

    @NotBlank(message = "Username is mandatory")
    private String username;

    @NotBlank(message = "Password is mandatory")
    private String password;

    private Role role; // Enum for role

    @Email(message = "Invalid email format")
    private String email;

    private String specialization; // Specific to DOCTOR role
    private Long contact;

    // Parameterized Constructor
    public UserDTO(Long id, String username, String password, Role role, String email, String specialization, Long contact) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
        this.specialization = specialization;
        this.contact = contact;
    }

    // Conversion methods (optional)
    public static UserDTO fromEntity(User user) {
        return new UserDTO(
                user.getId(),
                user.getUsername(),
                user.getPassword(),
                user.getRole(),
                user.getEmail(),
                user.getSpecialization(),
                user.getContact()
        );
    }

    public User toEntity() {
        User user = new User();
        user.setId(this.id);
        user.setUsername(this.username);
        user.setPassword(this.password);
        user.setRole(this.role); // Directly use the role enum
        user.setEmail(this.email);
        user.setSpecialization(this.specialization);
        user.setContact(this.contact); // Set contact as Long
        return user;
    }
}
