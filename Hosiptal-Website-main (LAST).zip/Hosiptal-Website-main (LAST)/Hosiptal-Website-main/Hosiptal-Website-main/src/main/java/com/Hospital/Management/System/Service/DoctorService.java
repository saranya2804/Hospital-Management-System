package com.Hospital.Management.System.Service;

import com.Hospital.Management.System.Entity.Appointment;
import com.Hospital.Management.System.Entity.Doctor;
import com.Hospital.Management.System.Entity.DoctorAvailability;
import com.Hospital.Management.System.Repositries.DoctorAvailabilityRepository;
import com.Hospital.Management.System.exceptions.ResourceNotFoundException;
import com.Hospital.Management.System.Repositries.AppointmentRepository;
import com.Hospital.Management.System.Repositries.DoctorRepository;
import com.Hospital.Management.System.dto.DoctorDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DoctorService {

    @Autowired
    private AppointmentRepository appointmentRepository;
    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private DoctorAvailabilityRepository doctorAvailabilityRepository;

    // Get Doctor's Appointments Count



    // Generate Bill for Appointment
    public double generateBill(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        return appointment.getFee();
    }

    // Accept Appointment
    public Appointment acceptAppointment(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        appointment.setStatus("Accepted");
        return appointmentRepository.save(appointment);
    }

    // CRUD Operations for Doctor

    // Save Doctor
    public DoctorDTO saveDoctor(DoctorDTO doctorDTO) {
        Doctor doctor = new Doctor();
        doctor.setName(doctorDTO.getName());
        doctor.setSpecialization(doctorDTO.getSpecialization());
        doctor.setContact(doctorDTO.getContact());
        doctor.setEmail(doctorDTO.getEmail());
        Doctor savedDoctor = doctorRepository.save(doctor);
        return new DoctorDTO(savedDoctor.getId(), savedDoctor.getName(),savedDoctor.getEmail(), savedDoctor.getSpecialization(), savedDoctor.getContact());
    }

    // Get Doctor by ID
    public Doctor getDoctorById(Long doctorId) {
        return doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
    }

    // Update Doctor Details
    public Doctor updateDoctor(Long doctorId, Doctor doctorDetails) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
        doctor.setName(doctorDetails.getName());
        doctor.setSpecialization(doctorDetails.getSpecialization());
        doctor.setContact(doctorDetails.getContact());
        return doctorRepository.save(doctor);
    }

    // Delete Doctor
    public void deleteDoctor(Long doctorId) {
        if (!doctorRepository.existsById(doctorId)) {
            throw new ResourceNotFoundException("Doctor not found");
        }
        doctorRepository.deleteById(doctorId);
    }

    // Get all Doctors
    public List<DoctorDTO> getAllDoctors() {
        List<Doctor> doctors = doctorRepository.findAll();
        return doctors.stream().map(doctor -> new DoctorDTO(
                        doctor.getId(), doctor.getName(),doctor.getEmail(), doctor.getSpecialization(), doctor.getContact()))
                .collect(Collectors.toList());
    }

    // Calculate Doctor's Earnings
    @Transactional
    public double calculateDoctorEarnings(Long doctorId) {
        List<Appointment> appointments = appointmentRepository.findByDoctor_Id(doctorId);
        return appointments.stream().mapToDouble(Appointment::getFee).sum();
    }


    public Appointment declineAppointment(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        appointment.setStatus("Declined");
        return appointmentRepository.save(appointment);
    }

    public DoctorAvailability addAvailability(Long doctorId, LocalDate date, String timeSlot) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

        DoctorAvailability availability = new DoctorAvailability();
        availability.setDoctor(doctor);
        availability.setDate(date);
        availability.setTimeSlot(timeSlot);

        return doctorAvailabilityRepository.save(availability);
    }

    public Long getDoctorByUserId(Long userId) {
        Long doctorId = doctorRepository.findDoctorIdByUserId(userId);
        if (doctorId == null) {
            throw new ResourceNotFoundException("Doctor not found for user ID: " + userId);
        }else{
            return doctorId;
        }
    }

    public Long getAppointmentsCount(Long doctorId) {
        return appointmentRepository.countByDoctorId(doctorId);
    }

    public DoctorAvailability addAppointmentsDateAndSlots(Long doctorId, DoctorAvailability doctorAvailability) {
        // Find the doctor by ID
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

        // Set the doctor to the doctorAvailability object
        doctorAvailability.setDoctor(doctor);

        // Save the doctorAvailability object to the repository
        return doctorAvailabilityRepository.save(doctorAvailability);
    }

    public List<DoctorAvailability> getAvailableSlotsAndDate(Long doctorId) {
        return doctorAvailabilityRepository.findAvailableSlotsAndDateByDoctorId(doctorId);
    }


    public String getDoctorName(Long doctorId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
        return doctor.getName();
    }
}
