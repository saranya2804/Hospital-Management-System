package com.Hospital.Management.System.dto;

import com.Hospital.Management.System.Entity.Doctor;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@AllArgsConstructor
@Setter
@NoArgsConstructor
public class DoctorDTO {

    private Long id;

    @NotBlank(message = "Name is mandatory")
    private String name;
    private String email;

    @NotBlank(message = "Specialization is mandatory")
    private String specialization;

    @NotBlank(message = "Contact is mandatory")
    private Long contact;

    // Conversion methods (optional)
    public static DoctorDTO fromEntity(Doctor doctor) {
       return new DoctorDTO(doctor.getId(), doctor.getName(),doctor.getEmail(), doctor.getSpecialization(),doctor.getContact());
    }

    public Doctor toEntity() {
        Doctor doctor = new Doctor();
        doctor.setId(this.id);
        doctor.setName(this.name);
        doctor.setSpecialization(this.specialization);
        doctor.setEmail(this.email);
        doctor.setContact(this.contact);
        return doctor;
    }
}
