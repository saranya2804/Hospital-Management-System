package com.Hospital.Management.System.dto;

import com.Hospital.Management.System.Entity.Patient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@AllArgsConstructor
@Setter
@NoArgsConstructor
public class PatientDTO {

    private Long id;

    @NotBlank(message = "Name is mandatory")
    private String name;

    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Contact is mandatory")
    private Long contact;


    // Conversion methods (optional)
    public static PatientDTO fromEntity(Patient patient) {
        return new PatientDTO(patient.getId(), patient.getName(), patient.getEmail(), patient.getContact());
    }

    public Patient toEntity() {
        Patient patient = new Patient();
        patient.setId(this.id);
        patient.setName(this.name);
        patient.setEmail(this.email);
        patient.setContact(this.contact);
        return patient;
    }
}
