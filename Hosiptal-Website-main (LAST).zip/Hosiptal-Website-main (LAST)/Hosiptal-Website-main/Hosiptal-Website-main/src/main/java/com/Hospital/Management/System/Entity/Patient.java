package com.Hospital.Management.System.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name="patients")
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String email;
	private Long contact;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;

	public Patient(User user) {
		this.user = user;
	}
}
