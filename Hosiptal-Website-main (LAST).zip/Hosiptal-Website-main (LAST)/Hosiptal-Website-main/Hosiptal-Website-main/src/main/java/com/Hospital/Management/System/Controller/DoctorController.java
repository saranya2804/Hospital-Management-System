package com.Hospital.Management.System.Controller;

import com.Hospital.Management.System.Entity.Appointment;
import com.Hospital.Management.System.Entity.DoctorAvailability;
import com.Hospital.Management.System.Service.DoctorService;
import com.Hospital.Management.System.dto.DoctorDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    // Get Doctor Details
    @GetMapping("/{userId}")
    public ResponseEntity<Long> getDoctorId(@PathVariable Long userId) {
        Long doctorDTO = doctorService.getDoctorByUserId(userId);
        return ResponseEntity.ok(doctorDTO);
    }

    // View Appointments
    @GetMapping("/{doctorId}/appointmentscount")
    public ResponseEntity<Long> getAppointmentsCount(@PathVariable Long doctorId) {
        Long count = doctorService.getAppointmentsCount(doctorId);
        return ResponseEntity.ok(count);
    }

    // Calculate Total Earnings
    @GetMapping("/{doctorId}/earnings")
    public ResponseEntity<Double> getTotalEarnings(@PathVariable Long doctorId) {
        double earnings = doctorService.calculateDoctorEarnings(doctorId);
        return ResponseEntity.ok(earnings);
    }

    // Generate Bill for Patient
    @GetMapping("/appointments/{appointmentId}/bill")
    public ResponseEntity<Double> generateBill(@PathVariable Long appointmentId) {
        double bill = doctorService.generateBill(appointmentId);
        return ResponseEntity.ok(bill);
    }
    @PostMapping("/addAppointmentsDateAndSlots/{doctorId}")
    public DoctorAvailability addAppointmentsDateAndSlots(@PathVariable Long doctorId, @RequestBody DoctorAvailability doctorAvailability) {
        return doctorService.addAppointmentsDateAndSlots(doctorId, doctorAvailability);
    }
    @GetMapping("/getAvailableSlotsAndDate/{doctorId}")
    public ResponseEntity<List<DoctorAvailability>> getAvailableSlotsAndDate(@PathVariable Long doctorId) {
        List<DoctorAvailability> availableSlots = doctorService.getAvailableSlotsAndDate(doctorId);
        return ResponseEntity.ok(availableSlots);
    }
    @GetMapping("/getDoctorName/{doctorId}")
    public ResponseEntity<String> getDoctorName(@PathVariable Long doctorId) {
        String doctorName = doctorService.getDoctorName(doctorId);
        return ResponseEntity.ok(doctorName);
    }
    @GetMapping("/all")
    public ResponseEntity<List<DoctorDTO>> getAllDoctors() {
        List<DoctorDTO> doctors = doctorService.getAllDoctors();
        return ResponseEntity.ok(doctors);
    }

}
