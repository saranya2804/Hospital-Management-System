package com.Hospital.Management.System.dto;

import lombok.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentDTO {

    private Long id;
    private LocalDate appointmentDate;
    private Long patientId; // Mapping patient by ID
    private Long doctorId; // Mapping doctor by ID
    private String patientName; // Optional for convenience
    private String doctorName; // Optional for convenience
    private Double fee;
    private String status = "Pending"; // Default status
    private String slot;
    private String healthIssue;
    private String prescription;

    public AppointmentDTO(String s) {
    }
}
