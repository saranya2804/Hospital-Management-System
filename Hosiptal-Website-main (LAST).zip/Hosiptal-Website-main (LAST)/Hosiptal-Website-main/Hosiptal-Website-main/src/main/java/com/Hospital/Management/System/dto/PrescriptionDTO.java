package com.Hospital.Management.System.dto;

public class PrescriptionDTO {
    private String medicineName;
    private String dosage;
    private String instructions;

    // Getters and Setters
    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public void setAppointmentId(Long id) {
    }

    public void setId(Long id) {

    }

    public void setMedication(String medicationDetails) {
    }

    public void setDoctorId(Long id) {
    }

    public void setPatientId(Long id) {
    }

    public Long getId() {
        return null; // Placeholder for actual implementation
    }

    public String getMedication() {
        return null; // Placeholder for actual implementation
    }
}
