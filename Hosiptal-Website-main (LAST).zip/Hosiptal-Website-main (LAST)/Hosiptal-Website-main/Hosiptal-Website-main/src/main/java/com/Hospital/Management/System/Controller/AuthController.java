package com.Hospital.Management.System.Controller;

import com.Hospital.Management.System.Entity.Role;
import com.Hospital.Management.System.Entity.User;
import com.Hospital.Management.System.Service.AuthService;
import com.Hospital.Management.System.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    // Login endpoint
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UserDTO userDTO) {
        User user = authService.authenticate(userDTO.getUsername(), userDTO.getPassword());

        if (user != null) {
            // Get user role and userId
            String userRole = user.getRole().name();  // Assuming Role is an enum in User entity
            Long userId = user.getId();
            return ResponseEntity.ok().body(new LoginResponse("Login successful", userRole, userId));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password!");
        }
    }

    // Registration endpoint
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody UserDTO userDTO) {
        String result = authService.registerUser(userDTO, userDTO.getRole());
        if (result.contains("User registered successfully")) {
            return ResponseEntity.ok().body(result);  // Return success response
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);  // Return failure response
        }
    }
    public static class LoginResponse {
        private String message;
        private String role;
        private long uid;

        public LoginResponse(String message, String role, long uid) {
            this.message = message;
            this.role = role;
            this.uid = uid;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }

        public long getUid() {
            return uid;
        }

        public void setUid(long uid) {
            this.uid = uid;
        }
    }
}
