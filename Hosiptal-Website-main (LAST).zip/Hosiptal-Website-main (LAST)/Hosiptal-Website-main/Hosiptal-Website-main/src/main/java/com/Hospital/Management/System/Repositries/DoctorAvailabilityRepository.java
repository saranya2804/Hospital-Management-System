package com.Hospital.Management.System.Repositries;

import com.Hospital.Management.System.Entity.DoctorAvailability;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface DoctorAvailabilityRepository extends JpaRepository<DoctorAvailability,Long> {
    List<DoctorAvailability> findByDoctorIdAndDate(Long doctorId, LocalDate date);

    List<DoctorAvailability> findAvailableSlotsAndDateByDoctorId(Long doctorId);
}
