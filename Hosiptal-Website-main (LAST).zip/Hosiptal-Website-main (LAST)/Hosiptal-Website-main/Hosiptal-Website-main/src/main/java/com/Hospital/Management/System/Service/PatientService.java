package com.Hospital.Management.System.Service;

import com.Hospital.Management.System.Entity.Patient;
import com.Hospital.Management.System.Repositries.PatientRepository;
import com.Hospital.Management.System.dto.PatientDTO;
import com.Hospital.Management.System.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    // Convert Patient entity to DTO
    private PatientDTO convertToDto(Patient patient) {
        return new PatientDTO(patient.getId(), patient.getName(), patient.getEmail(), patient.getContact());
    }

    // Convert Patient DTO to entity
    private Patient convertToEntity(PatientDTO patientDTO) {
        Patient patient = new Patient();
        patient.setName(patientDTO.getName());
        patient.setEmail(patientDTO.getEmail());
        patient.setContact(patientDTO.getContact());
        return patient;
    }

    // Create Patient
    public PatientDTO createPatient(PatientDTO patientDTO) {
        Patient patient = convertToEntity(patientDTO);
        return convertToDto(patientRepository.save(patient));
    }

    // Get Patient by ID
    public PatientDTO getPatientById(Long id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));
        return convertToDto(patient);
    }

    // Update Patient
    public PatientDTO updatePatient(Long id, PatientDTO patientDTO) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));
        patient.setName(patientDTO.getName());
        patient.setEmail(patientDTO.getEmail());
        patient.setContact(patientDTO.getContact());
        return convertToDto(patientRepository.save(patient));
    }

    // Delete Patient
    public void deletePatient(Long id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));
        patientRepository.delete(patient);
    }

    // Get all Patients
    public List<PatientDTO> getAllPatients() {
        return patientRepository.findAll().stream().map(this::convertToDto).collect(Collectors.toList());
    }

    // Get Patient by User ID
    public PatientDTO getPatientByUserId(Long userId) {
        Patient patient = patientRepository.findByUserId(userId);
        if (patient != null) {
            return convertToDto(patient);
        } else {
            throw new ResourceNotFoundException("Patient not found for user ID: " + userId);
        }
    }

    // Get Patient Count
    public long getPatientCount() {
        return patientRepository.count();
    }


}
