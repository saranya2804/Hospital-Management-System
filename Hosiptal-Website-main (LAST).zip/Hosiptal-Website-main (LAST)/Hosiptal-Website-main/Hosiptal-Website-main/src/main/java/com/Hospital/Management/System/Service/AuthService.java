package com.Hospital.Management.System.Service;

import com.Hospital.Management.System.Entity.Doctor;
import com.Hospital.Management.System.Entity.Patient;
import com.Hospital.Management.System.Entity.Role;
import com.Hospital.Management.System.Entity.User;
import com.Hospital.Management.System.Repositries.DoctorRepository;
import com.Hospital.Management.System.Repositries.PatientRepository;
import com.Hospital.Management.System.Repositries.UserRepository;
import com.Hospital.Management.System.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private PatientRepository patientRepository;

    // Authenticate User by Username and Password
    public User authenticate(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password);
    }

    // Register User with Role
    public String registerUser(UserDTO userDTO, Role role) {
        // Check if user already exists
        if (userRepository.findByUsername(userDTO.getUsername()).isPresent()) {
            return "Username already exists!";
        }

        User user = new User();  // Assuming User entity has a default constructor

        // Set properties from UserDTO to User entity
        user.setUsername(userDTO.getUsername());
        user.setPassword(userDTO.getPassword());
        user.setEmail(userDTO.getEmail());
        user.setContact(userDTO.getContact());  // Ensure contact is set
        user.setRole(role);
        user.setSpecialization(userDTO.getSpecialization());


        // Validate role and create corresponding entity
        if (Role.DOCTOR.equals(role)) {
            user.setRole(Role.DOCTOR);  // Set role to DOCTOR
            Doctor doctor = new Doctor(user);  // Create Doctor with User
            doctor.setName(userDTO.getUsername()); // Optional: set name for doctor
            doctor.setSpecialization(userDTO.getSpecialization()); // Set specialization
            doctor.setContact(userDTO.getContact());  // Ensure contact is set here too
            doctor.setEmail(userDTO.getEmail());
            doctorRepository.save(doctor);  // Save Doctor entity
        } else if (Role.PATIENT.equals(role)) {
            user.setRole(Role.PATIENT);  // Set role to PATIENT
            Patient patient = new Patient(user);  // Create Patient with User
            patient.setName(userDTO.getUsername());
            patient.setContact(userDTO.getContact());
            patient.setEmail(userDTO.getEmail());
            patientRepository.save(patient);  // Save Patient entity
        } else {
            return "Invalid role provided!";
        }

        // Save User entity after role-specific entity
        userRepository.save(user);  // Save User entity

        // Return success message with UID
        return "User registered successfully as " + role.name() + "! UID: " + user.getId();
    }
}
